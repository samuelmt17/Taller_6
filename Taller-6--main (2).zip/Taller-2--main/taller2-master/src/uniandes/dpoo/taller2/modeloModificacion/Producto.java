package uniandes.dpoo.taller2.modeloModificacion;

public interface Producto 

{
	public String getNombre();
	
	public int getPrecio();
	
	public String generarTextoFactura();
	
	public int getCalorias();

}
