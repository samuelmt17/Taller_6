package uniandes.dpoo.taller2.procesamiento;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import uniandes.dpoo.taller2.modelo.Ingrediente;
import uniandes.dpoo.taller2.modelo.Pedido;
import uniandes.dpoo.taller2.modelo.ProductoMenu;
import uniandes.dpoo.taller2.modelo.Combo;

public class Restaurante {
    private static List<ProductoMenu> menuBase;
    private static List<Ingrediente> ingredientes;
    private static List<Combo> combos;
    private static Map<String, Pedido> pedidos;
    private static Pedido pedidoEnCurso;

    public static List<ProductoMenu> getMenuBase() {
        return menuBase;
    }

    public static List<Ingrediente> getIngredientes() {
        return ingredientes;
    }

    public static List<Combo> getCombos() {
        return combos;
    }

    public static void cargarInformacionRestaurante(String archivo1, String archivo2, String archivo3)
            throws FileNotFoundException, IOException {
        try {
            ingredientes = cargarIngredientes(archivo1);
            menuBase = cargarMenu(archivo2);
            combos = cargarCombos(archivo3);
            pedidos = new HashMap<String, Pedido>();
            System.out.println("La información del restaurante se cargó exitosamente.");
        } catch (IngredienteRepetidoException e) {
            System.out.println("Error al cargar los ingredientes: " + e.getMensaje());
        } catch (ProductoRepetidoException e) {
            System.out.println("Error al cargar el menú: " + e.getMensaje());
        } catch (FileNotFoundException e) {
            System.out.println("Archivo no encontrado: " + e.getMessage());
        } catch (IOException e) {
            System.out.println("Error de lectura/escritura en el archivo: " + e.getMessage());
        }
    }

    private static List<Ingrediente> cargarIngredientes(String nombreArchivo)
            throws FileNotFoundException, IOException, IngredienteRepetidoException {
        List<Ingrediente> listaIngredientes = new ArrayList<>();

        BufferedReader br = new BufferedReader(new FileReader(nombreArchivo));
        String linea = br.readLine();
        while (linea != null) {
            String[] partes = linea.split(";");
            String nombreIngrediente = partes[0];
            int precioAdicional = Integer.parseInt(partes[1]);

            Ingrediente elIngrediente = new Ingrediente(nombreIngrediente, precioAdicional);

            // Verificar si el ingrediente ya existe en la lista
            if (listaIngredientes.contains(elIngrediente)) {
                throw new IngredienteRepetidoException(nombreIngrediente);
            }

            listaIngredientes.add(elIngrediente);
            linea = br.readLine();
        }

        br.close();

        return listaIngredientes;
    }

    private static List<ProductoMenu> cargarMenu(String nombreArchivo)
            throws FileNotFoundException, IOException, ProductoRepetidoException {
        List<ProductoMenu> listaMenu = new ArrayList<>();

        BufferedReader br = new BufferedReader(new FileReader(nombreArchivo));
        String linea = br.readLine();
        while (linea != null) {
            String[] partes = linea.split(";");
            String nombreMenu = partes[0];
            int costoBase = Integer.parseInt(partes[1]);

            ProductoMenu elMenu = new ProductoMenu(nombreMenu, costoBase);

            // Verificar si el producto ya existe en la lista
            if (listaMenu.contains(elMenu)) {
                throw new ProductoRepetidoException(nombreMenu);
            }

            listaMenu.add(elMenu);
            linea = br.readLine();
        }

        br.close();

        return listaMenu;
    }

    private static List<Combo> cargarCombos(String nombreArchivo) throws FileNotFoundException, IOException {
        List<Combo> listaCombos = new ArrayList<>();

        try (BufferedReader br = new BufferedReader(new FileReader(nombreArchivo))) {
            String linea = br.readLine();
            while (linea != null) {
                String[] partes = linea.split(";");
                String nombreCombo = partes[0];
                int descuento = Integer.parseInt(partes[1].replace("%", ""));

                Combo elCombo = new Combo(nombreCombo, descuento);

                String producto1Menu = partes[2];
                String producto2Menu = partes[3];
                String producto3Menu = partes[4];

                List<ProductoMenu> menu = Restaurante.getMenuBase();

                for (ProductoMenu productoMenu : menu) {
                    if (productoMenu.getNombre().equals(producto1Menu) || productoMenu.getNombre().equals(producto2Menu)
                            || productoMenu.getNombre().equals(producto3Menu)) {
                        elCombo.agregarItemACombo(productoMenu);
                    }
                }

                listaCombos.add(elCombo);
                linea = br.readLine();
            }

            System.out.println("Los combos se cargaron exitosamente.");
        } catch (FileNotFoundException e) {
            System.out.println("Archivo no encontrado: " + e.getMessage());
        } catch (IOException e) {
            System.out.println("Error de lectura/escritura en el archivo: " + e.getMessage());
        }

        return listaCombos;
    }

    public double calcularValorTotal() throws ValorTotalExcedidoException {
        double valorTotal = // cálculo del valor total del pedido

        if (valorTotal > 150000) {
            throw new ValorTotalExcedidoException(valorTotal);
        }

        return valorTotal;
    }

    public static void IniciarPedido(String nombreCliente, String direccionCliente) {
        Pedido pedidoOrden = new Pedido(nombreCliente, direccionCliente);
        pedidoEnCurso = pedidoOrden;
    }

    public static Pedido getPedidoEnCurso() {
        return pedidoEnCurso;
    }

    public static void cerrarYGuardarPedido() throws IOException {
        pedidoEnCurso.guardarFactura();
        pedidos.put(String.valueOf(pedidoEnCurso.getIdPedido()), pedidoEnCurso);
        pedidoEnCurso = null;
    }

    public static String ConsultarPedido(int idPedido) throws FileNotFoundException, IOException {
        BufferedReader br = new BufferedReader(new FileReader("./data/" + String.valueOf(idPedido) + ".txt"));
        String linea = br.readLine();
        String factura = "";

        while (linea != null) {
            factura += linea + "\n";
            linea = br.readLine();
        }

        System.out.println("La información del pedido es:");
        Pedido pedidoSolicitado = pedidos.get(String.valueOf(idPedido));

        try {
            double valorTotal = pedidoSolicitado.calcularValorTotal();
            System.out.println("El valor total del pedido es: " + valorTotal);
        } catch (ValorTotalExcedidoException e) {
            System.out.println("El valor total del pedido excede el límite: " + e.getValorTotal());
            return null;
        }

        br.close();

        return factura;
    }
}
