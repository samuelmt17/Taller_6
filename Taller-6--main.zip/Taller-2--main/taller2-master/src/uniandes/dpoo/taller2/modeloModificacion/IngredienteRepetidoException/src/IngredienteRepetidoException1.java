
public class IngredienteRepetidoException1 extends HamburguesaException1 {
    private static final long serialVersionUID = 1L;
    private String ingrediente;

    public IngredienteRepetidoException1(String ingrediente) {
        super("Ingrediente repetido: " + ingrediente);
        this.ingrediente = ingrediente;
    }

    public String getIngrediente() {
        return ingrediente;
    }
}
