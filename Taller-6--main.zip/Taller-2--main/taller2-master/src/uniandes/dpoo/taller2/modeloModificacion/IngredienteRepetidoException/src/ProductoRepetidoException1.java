
public class ProductoRepetidoException1 extends HamburguesaException1 {
    private static final long serialVersionUID = 1L;
    private String producto;

    public ProductoRepetidoException1(String producto) {
        super("Producto repetido: " + producto);
        this.producto = producto;
    }

    public String getProducto() {
        return producto;
    }
}
